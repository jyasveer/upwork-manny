<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/flick/jquery-ui.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.jqueryscript.net/demo/jQuery-International-Telephone-Input-With-Flags-Dial-Codes/build/css/intlTelInput.css">
  <link rel="stylesheet" href="https://www.jqueryscript.net/demo/Stylish-jQuery-Select-Box-Plugin-with-Smooth-Drop-Down-Effects-FancySelect/fancySelect.css">

  <link rel="stylesheet" href="style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>
<script src="https://trentrichardson.com/examples/timepicker/i18n/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-sliderAccess.js"></script>
<script src="https://www.jqueryscript.net/demo/jQuery-International-Telephone-Input-With-Flags-Dial-Codes/build/js/intlTelInput.js"></script>
<script src="https://www.jqueryscript.net/demo/Stylish-jQuery-Select-Box-Plugin-with-Smooth-Drop-Down-Effects-FancySelect/fancySelect.js"></script>

<script>
function validateForm() {
  var x = document.forms["myForm"]["name"].value;
  var y = document.forms["myForm"]["email"].value;
  var z = document.forms["myForm"]["datetime"].value;
  var a = document.forms["myForm"]["phone"].value;
  var b = document.forms["myForm"]["service"].value;
  var p = document.forms["myForm"]["privacy"].value;
  
  
  
  var i = 0;
  
  if (x == "") {
      i = 1;
    document.getElementById("name_error").style.display = "block";
    /*return false;*/
  }
  
  if (y == "") {
      i = 1;
    document.getElementById("email_error").style.display = "block";
    /*return false;*/
  }
  
  if (z == "") {
    
    i = 1;
    document.getElementById("datetime_error").style.display = "block";
    
  }
  
   if (a == "") {
    
    i = 1;
    document.getElementById("phone_error").style.display = "block";
    
  }
  
  if (b == "") {
    
    i = 1;
    document.getElementById("service_error").style.display = "block";
    
  }
  
  if (p == "") {
    
    i = 1;
    document.getElementById("privacy_error").style.display = "block";
    
  }
  
  
  if(i == 1){
    return false;  
  }
  
}
</script>
</head>
<body>

<div class="container">
 <div class="form-main-wrap"> 
  <div class="form-align-center">
  <form name="myForm" class="form-horizontal" onsubmit="return validateForm()">
   
	<div class="form-group">
      <div class="col-sm-12">
        <input type="text" class="form-control input-lg" id="Fname" placeholder="Full Name" name="name">
      </div>
    </div>
	<div class="form-group">
      <div class="col-sm-12">
        <input type="email" class="form-control input-lg" id="email" placeholder="E-mail" name="email">
      </div>
    </div>
    
    <div class="form-group">
      <div class="col-sm-6">
        <!--<input type="email" class="form-control input-lg" id="Lname" placeholder="Last Name" name="email">-->
		<input type="text" class="form-control input-lg" id="datetime" placeholder="Date Time" name="datetime">
      </div>
      <div class="col-sm-6 phoneinput">
				<div class="input-group phone-input">
					<input type="tel" id="phone" placeholder="" name="phone"  id="telephone">
				</div>
		</div>
    </div>
	
    <div class="form-group">
		<div class="col-sm-12"> 
			<label>Choose your Services</label>
			<select name="service" class="form-control input-lg service">
				<option value="">Service</option>
				<option value="Hosting/Cloud Solutions">Hosting/Cloud Solutions</option>
				<option value="Artificial Intelligence">Artificial Intelligence</option>
				<option value="Machine Learning Development">Machine Learning Development</option>
				<option value="Virtual/Augmented Reality and Development">Virtual/Augmented Reality and Development</option>
				<option value="Design &amp; Branding">Design &amp; Branding</option>
				<option value="IoT">IoT</option>
				<option value="Chat Bot Development">Chat Bot Development</option>
				<option value="Internet Security">Internet Security</option>
				<option value="Mobile App Development">Mobile App Development</option>
				<option value="Website Development">Website Development</option>
				<option value="Digital Marketing Services">Digital Marketing Services</option>
				<option value="Big Data">Big Data</option>
				<option value="ICO Blockchain Development">ICO Blockchain Development</option>
				<option value="Game Development">Game Development</option>
				<option value="Virtual Assistance">Virtual Assistance</option>
				<option value="Wearable Tech">Wearable Tech</option>
				<option value="Robotic Automation">Robotic Automation</option>
				<option value="Animation">Animation</option>
				<option value="3D Modelling">3D Modelling</option>
				<option value="IT Support">IT Support</option>
				<option value="Accounting Services">Accounting Services</option>
				<option value="Email Marketing">Email Marketing</option>
				<option value="Content Writing">Content Writing</option>
				<option value="Legal Services">Legal Services</option>
				<option value="Business Intelligence">Business Intelligence</option>
				<option value="Consulting">Consulting</option>
			</select>
		</div>
    </div>

    <div class="form-group">        
      <div class=" col-sm-12">
        <div class="custom-checkbox">
        	<input id="privacy" type="checkbox" name="privacy">
        	<label for="privacy"> <span></span>I Agree to my contact details being stored and used by Mango consulting to contact me. Read more in Our Privacy Policy</label>
        </div>
      </div>
    </div>
	<div class="form-group">        
      <div class=" col-sm-12">
      	<div class="custom-checkbox">
        	<input id="updates" type="checkbox" name="updates">
        	<label for="updates"> <span></span>I'd like to receive Mango Consulting Weekly updates directly to my inbox.</label>
        </div>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-12">
          <span class="error" id="name_error" style="display:none;">X Please enter name</span>
          <span class="error" id="email_error" style="display:none;">X Please enter email</span>
          <span class="error" id="datetime_error" style="display:none;">X Please select date & time</span>
          <span class="error" id="phone_error" style="display:none;">X Please enter phone</span>
          <span class="error" id="service_error" style="display:none;">X Please select service</span>
          <span class="error" id="privacy_error" style="display:none;">X Please select privacy</span>
          
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-6 submit_div">
          <input type="submit" class="submit_btn" value="Submit">
        <!--<button type="submit" class="btn btn-primary">Submit</button>-->
      </div>
    </div>
  </form>
  <div class="right-side-img">
	<img src="index.jfif" height="600px" width="400px" />
  </div>
</div>
</div>
</div>


<script type="text/javascript">
  $(document).ready(function () {
      
      var dateNow = new Date();
      
	  $('#datetime').datetimepicker({
            dateFormat: 'dd-m-yy', 
            minDate: 0,
            maxDate: '+5Y',
            duration: '',
            
            constrainInput: false,
            timeFormat: 'hh:mm'
        });
		$("#phone").intlTelInput({
		    preferredCountries: [ "gb","us"  ],
		}); 
		$('.service').fancySelect();
		
        

  });
  
  
</script>


</body>
</html>
